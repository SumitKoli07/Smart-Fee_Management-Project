const mongoose = require('mongoose');

const RequestSchema = new mongoose.Schema({
    clientId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'clientRegister',
        required: true
    },
    serviceId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ownerRegister',
        required: true
    },
    ownerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ownerRegister',
        required: true
    },
    planType: {
        type: String,
        required: true
    },
    planAmount: {
        type: Number,
        required: true
    },
    status: {
        type: String,
        enum: ['pending', 'approved', 'rejected'],
        default: 'pending'
    },
    // Direct access to client email for easy querying
    clientEmail: {
        type: String,
        index: true // Add index for faster lookups by email
    },
    // Payment tracking fields
    paymentStatus: {
        type: String,
        enum: ['unpaid', 'paid', 'overdue'],
        default: 'unpaid'
    },
    lastPaymentDate: {
        type: Date
    },
    nextDueDate: {
        type: Date
    },
    // End of payment tracking fields
    requestDate: {
        type: Date,
        default: Date.now
    },
    approvedDate: {
        type: Date
    },
    notes: {
        type: String
    },
    // Client details for quick access without joins
    clientDetails: {
        fullname: { type: String },
        email: { type: String },
        mobile: { type: String },
        address: { type: String },
        city: { type: String },
        state: { type: String }
    },
    // Service details for quick access without joins
    serviceDetails: {
        businessName: { type: String },
        serviceName: { type: String },
        ownerName: { type: String }
    }
}, {
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

// Create a compound index to prevent duplicate requests
RequestSchema.index({ clientId: 1, serviceId: 1, status: 1 }, { 
    unique: false // Not enforcing uniqueness but creating an index for faster queries 
});

// Add virtual field for days remaining
RequestSchema.virtual('daysRemaining').get(function() {
    if (!this.nextDueDate || !this.lastPaymentDate) {
        return null;
    }
    
    const nextDue = new Date(this.nextDueDate);
    const lastPayment = new Date(this.lastPaymentDate);
    const today = new Date();
    
    // Calculate days between next due date and today
    const timeDiff = nextDue - today;
    const daysRemaining = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
    
    return daysRemaining;
});

// Add virtual field for total days between last payment and next due date
RequestSchema.virtual('totalDaysRemaining').get(function() {
    if (!this.nextDueDate || !this.lastPaymentDate) {
        return null;
    }
    
    const nextDue = new Date(this.nextDueDate);
    const lastPayment = new Date(this.lastPaymentDate);
    
    // Calculate total days between last payment and next due date
    const timeDiff = nextDue - lastPayment;
    const totalDays = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
    
    return totalDays;
});

module.exports = mongoose.model('Request', RequestSchema, 'requests'); 