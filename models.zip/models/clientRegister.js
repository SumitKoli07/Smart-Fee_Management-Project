const mongoose = require('mongoose');

// Create client schema
const clientSchema = new mongoose.Schema({
    fullname: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    dob: { type: Date, required: true },
    gender: { type: String, required: true },
    mobile: { type: String, required: true },
    altMobile: { type: String },
    address: { type: String, required: true },
    state: { type: String, required: true },
    city: { type: String, required: true },
    pincode: { type: String, required: true },
    password: { type: String, required: true },
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'ownerRegister' },
    registrationDate: { type: Date, default: Date.now },
    
    
});

module.exports = mongoose.model('clientRegister', clientSchema); 