const mongoose = require('mongoose');

// Create owner schema - Based on the schema in server.js
const ownerSchema = new mongoose.Schema({
    businessName: { type: String, required: true },
    ownerName: { type: String, required: true },
    businessEmail: { type: String, required: true, unique: true },
    businessPhone: { type: String, required: true },
    businessAddress: { type: String, required: true },
    registrationNo: { type: String, required: true },
    taxID: { type: String, required: true },
    serviceName: { type: String, required: true },
    serviceDescription: { type: String },
    capacity: { type: Number, required: true },
    businessType: { type: String, required: true },
    otherBusinessType: { type: String },
    paymentSettings: { 
        type: [
            {
                name: { type: String, required: true },
                amount: { type: Number, default: 0 }
            }
        ],
        default: []
    }, // Array of payment settings with amounts
    paymentSetting: { type: String }, // Single payment setting (for backward compatibility)
    // Key-value object for payment options
    paymentOptions: { 
        type: mongoose.Schema.Types.Mixed, 
        default: {} 
    }, // Stores payment options as direct key-value pairs (e.g., {monthly: 100, quarterly: 250})
    // Specific payment period amounts
    monthlyAmount: { type: Number, default: 0 }, // Amount for monthly payment
    quarterlyAmount: { type: Number, default: 0 }, // Amount for quarterly payment
    halfYearlyAmount: { type: Number, default: 0 }, // Amount for half-yearly payment
    yearlyAmount: { type: Number, default: 0 }, // Amount for yearly payment
    password: { type: String, required: true },
    businessDoc: { type: String }, // Path to uploaded file
    taxDoc: { type: String }, // Path to uploaded file
    registrationDate: { type: Date, default: Date.now },
    createdAt: { type: Date, default: Date.now },
    serviceFee: { type: Number, required: true },// Service fee for the owner
    discountStrategy: { 
        type: String, 
        enum: ['default', 'aggressive', 'conservative'], 
        default: 'default'
    },
    
});

module.exports = mongoose.model('ownerRegister', ownerSchema); 