document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements
    const profileSettingsForm = document.getElementById('profileSettingsForm');
    const formLoading = document.getElementById('formLoading');
    const formContent = document.getElementById('formContent');
    const changePasswordForm = document.getElementById('changePasswordForm');

    // Owner data cache
    let ownerData = null;

    // Initialize user interface elements
    initializeUI();
    
    // Load owner profile data
    loadProfileData();

    // Function to initialize UI elements and event listeners
    function initializeUI() {
        // Initialize profile settings form submission
        if (profileSettingsForm) {
            profileSettingsForm.addEventListener('submit', function(e) {
                e.preventDefault();
                saveProfileData();
            });
        }

        // Initialize change password form submission
        if (changePasswordForm) {
            changePasswordForm.addEventListener('submit', function(e) {
                e.preventDefault();
                changePassword();
            });
        }

        // Set user initials
        updateUserInitials();
    }

    // Fetch and load owner profile data
    async function loadProfileData() {
        try {
            // Get the token from localStorage
            const token = localStorage.getItem('ownerToken');
            if (!token) {
                showToast('Authentication required. Please log in again.', false);
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 2000);
                return;
            }

            // Show loading state
            formLoading.classList.remove('hidden');
            formContent.classList.add('hidden');

            // Fetch owner profile data from the profile endpoint
            const profileResponse = await fetch('http://localhost:3000/api/owner/profile', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (!profileResponse.ok) {
                throw new Error(`Failed to fetch profile data: ${profileResponse.status}`);
            }

            const profileData = await profileResponse.json();
            
            if (!profileData.success) {
                throw new Error(profileData.message || 'Failed to load profile data');
            }
            
            // Cache the basic owner data
            ownerData = profileData.owner;
            
            // Now fetch additional payment settings data from ownerregisters collection
            const paymentSettingsResponse = await fetch('http://localhost:3000/api/owner/payment-settings', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            if (paymentSettingsResponse.ok) {
                const paymentSettingsData = await paymentSettingsResponse.json();
                
                if (paymentSettingsData.success && paymentSettingsData.settings) {
                    console.log("Payment settings data loaded:", paymentSettingsData.settings);
                    
                    // Merge payment settings into owner data
                    if (paymentSettingsData.settings.paymentSettings) {
                        ownerData.paymentSettings = paymentSettingsData.settings.paymentSettings;
                    }
                    
                    if (paymentSettingsData.settings.paymentSetting) {
                        ownerData.paymentSetting = paymentSettingsData.settings.paymentSetting;
                    }
                    
                    if (paymentSettingsData.settings.serviceFee !== undefined) {
                        ownerData.serviceFee = paymentSettingsData.settings.serviceFee;
                    }
                }
            } else {
                console.warn("Could not fetch payment settings, using profile data only");
            }
            
            // Populate the form with the combined owner data
            populateFormWithData(ownerData);
            
            // Show the form content and hide the loading spinner
            formLoading.classList.add('hidden');
            formContent.classList.remove('hidden');
            
            // Set user name and initials
            updateUserInitials();
        } catch (error) {
            console.error('Error loading profile data:', error);
            showToast(error.message || 'Failed to load profile data', false);
            
            // Show error state
            formLoading.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-red-500 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p class="text-red-500 font-medium">Failed to load profile data.</p>
                <button id="retryLoadBtn" class="mt-3 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Retry</button>
            `;
            
            // Add retry button event listener
            document.getElementById('retryLoadBtn').addEventListener('click', loadProfileData);
        }
    }

    // Populate the form with the owner data
    function populateFormWithData(owner) {
        console.log("Populating form with owner data:", owner);
        
        // Business Information
        document.getElementById('businessName').value = owner.businessName || '';
        document.getElementById('ownerName').value = owner.ownerName || '';
        document.getElementById('serviceDescription').value = owner.serviceDescription || '';
        document.getElementById('capacity').value = owner.capacity || '';
        
        // Contact Information
        document.getElementById('businessEmail').value = owner.businessEmail || '';
        document.getElementById('businessPhone').value = owner.businessPhone || '';
        document.getElementById('businessAddress').value = owner.businessAddress || '';
        
        // Payment Settings - Service Fee
        if (owner.serviceFee !== undefined && owner.serviceFee !== null) {
            document.getElementById('serviceFee').value = owner.serviceFee;
        }
        
        // Clear all checkboxes first
        document.querySelectorAll('input[name="paymentSetting"]').forEach(checkbox => {
            checkbox.checked = false;
        });
        
        // Handle paymentSettings (array format)
        if (owner.paymentSettings && Array.isArray(owner.paymentSettings) && owner.paymentSettings.length > 0) {
            console.log("Found paymentSettings array:", owner.paymentSettings);
            owner.paymentSettings.forEach(setting => {
                if (setting && setting.name) {
                    const checkbox = document.querySelector(`input[name="paymentSetting"][value="${setting.name}"]`);
                    if (checkbox) {
                        checkbox.checked = true;
                    }
                }
            });
        } 
        // Handle paymentSetting (string format) as fallback
        else if (owner.paymentSetting && typeof owner.paymentSetting === 'string') {
            console.log("Found paymentSetting string:", owner.paymentSetting);
            const paymentOptions = owner.paymentSetting.split(',');
            paymentOptions.forEach(option => {
                if (option && option.trim()) {
                    const checkbox = document.querySelector(`input[name="paymentSetting"][value="${option.trim()}"]`);
                    if (checkbox) {
                        checkbox.checked = true;
                    }
                }
            });
        }
        
        // Log which payment options were checked
        const checkedOptions = Array.from(document.querySelectorAll('input[name="paymentSetting"]:checked'))
            .map(checkbox => checkbox.value);
        console.log("Checked payment options:", checkedOptions);
    }

    // Save profile data
    async function saveProfileData() {
        try {
            // Get the token from localStorage
            const token = localStorage.getItem('ownerToken');
            if (!token) {
                showToast('Authentication required. Please log in again.', false);
                return;
            }

            // Check if at least one payment setting is selected
            const paymentSettings = document.querySelectorAll('input[name="paymentSetting"]:checked');
            if (paymentSettings.length === 0) {
                showToast('Please select at least one payment setting', false);
                return;
            }

            // Get form values
            const formData = {
                businessName: document.getElementById('businessName').value,
                ownerName: document.getElementById('ownerName').value,
                serviceDescription: document.getElementById('serviceDescription').value,
                capacity: document.getElementById('capacity').value,
                businessEmail: document.getElementById('businessEmail').value,
                businessPhone: document.getElementById('businessPhone').value,
                businessAddress: document.getElementById('businessAddress').value,
            };

            // Keep existing serviceFee value from owner data
            if (ownerData && ownerData.serviceFee !== undefined) {
                formData.serviceFee = ownerData.serviceFee;
            }

            // Add payment settings
            const paymentSettingValues = Array.from(paymentSettings).map(checkbox => checkbox.value);
            formData.paymentSetting = paymentSettingValues.join(',');

            // Format payment settings as an array for the API
            const paymentSettingsArray = paymentSettingValues.map(value => ({
                name: value,
                amount: ownerData && ownerData.paymentSettings ? 
                    // Try to find existing amount for this setting
                    (ownerData.paymentSettings.find(s => s.name === value)?.amount || 0) : 
                    // Fallback to service fee
                    (ownerData?.serviceFee || 0)
            }));
            formData.paymentSettings = paymentSettingsArray;

            // Validate form data
            if (!formData.businessName || !formData.ownerName || 
                !formData.businessEmail || !formData.businessPhone || !formData.businessAddress) {
                showToast('Please fill in all required fields', false);
                return;
            }

            // Show loading state
            const submitButton = profileSettingsForm.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.innerHTML;
            submitButton.disabled = true;
            submitButton.innerHTML = '<svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Saving...';
            
            // Send the data to the API
            const response = await fetch('http://localhost:3000/api/owner/profile', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(formData)
            });
            
            const data = await response.json();
            
            if (data.success) {
                showToast('Profile settings updated successfully');
                
                // Update cached owner data
                ownerData = data.owner;
                
                // Update user initials
                updateUserInitials();
            } else {
                throw new Error(data.message || 'Failed to update profile settings');
            }
        } catch (error) {
            console.error('Error updating profile settings:', error);
            showToast(error.message || 'Failed to update profile settings', false);
        } finally {
            // Reset button state
            const submitButton = profileSettingsForm.querySelector('button[type="submit"]');
            submitButton.disabled = false;
            submitButton.innerHTML = 'Save Changes';
        }
    }

    // Change password
    async function changePassword() {
        try {
            // Get the token from localStorage
            const token = localStorage.getItem('ownerToken');
            if (!token) {
                showToast('Authentication required. Please log in again.', false);
                return;
            }

            // Get form values
            const currentPassword = document.getElementById('currentPassword').value;
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            // Validate input
            if (!currentPassword || !newPassword || !confirmPassword) {
                showToast('Please fill in all password fields', false);
                return;
            }

            if (newPassword !== confirmPassword) {
                showToast('New passwords do not match', false);
                return;
            }

            // Validate password strength
            const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
            if (!passwordRegex.test(newPassword)) {
                showToast('Password must be at least 8 characters and include uppercase, lowercase, number, and special character', false);
                return;
            }

            // Show loading state
            const submitButton = changePasswordForm.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.innerHTML;
            submitButton.disabled = true;
            submitButton.innerHTML = '<svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Updating...';
            
            // Send the data to the API
            const response = await fetch('http://localhost:3000/api/owner/change-password', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    currentPassword,
                    newPassword
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                showToast('Password updated successfully');
                
                // Clear password fields
                document.getElementById('currentPassword').value = '';
                document.getElementById('newPassword').value = '';
                document.getElementById('confirmPassword').value = '';
            } else {
                throw new Error(data.message || 'Failed to update password');
            }
        } catch (error) {
            console.error('Error updating password:', error);
            showToast(error.message || 'Failed to update password', false);
        } finally {
            // Reset button state
            const submitButton = changePasswordForm.querySelector('button[type="submit"]');
            submitButton.disabled = false;
            submitButton.innerHTML = 'Update Password';
        }
    }

    // Update user initials and name in the header
    function updateUserInitials() {
        if (ownerData && ownerData.ownerName) {
            const userInitialsElem = document.getElementById('userInitials');
            const userNameElem = document.getElementById('userName');
            
            if (userInitialsElem) {
                // Get initials from owner name
                const nameParts = ownerData.ownerName.split(' ');
                const initials = nameParts.map(part => part[0]).join('').toUpperCase();
                userInitialsElem.textContent = initials;
            }
            
            if (userNameElem) {
                userNameElem.textContent = ownerData.ownerName;
            }
        }
    }

    // Show a toast notification
    function showToast(message, success = true) {
        const toast = document.getElementById('toastNotification');
        const toastMessage = document.getElementById('toastMessage');
        
        if (toast && toastMessage) {
            // Set message and style
            toastMessage.textContent = message;
            
            if (success) {
                toast.classList.remove('bg-red-500');
                toast.classList.add('bg-green-500');
            } else {
                toast.classList.remove('bg-green-500');
                toast.classList.add('bg-red-500');
            }
            
            // Show the toast
            gsap.to(toast, {
                y: -20,
                opacity: 1,
                duration: 0.3,
                onComplete: function() {
                    // Hide after 3 seconds
                    setTimeout(function() {
                        gsap.to(toast, {
                            y: 20,
                            opacity: 0,
                            duration: 0.3
                        });
                    }, 3000);
                }
            });
        }
    }
}); 