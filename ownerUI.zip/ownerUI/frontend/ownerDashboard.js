document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    const isOwnerLoggedIn = localStorage.getItem('isOwnerLoggedIn') === 'true';
    const ownerToken = localStorage.getItem('ownerToken');
    
    if (!isOwnerLoggedIn || !ownerToken) {
        // If not logged in, redirect to login page
        window.location.href = 'ownerLogin.html';
        return;
    }
    
    // Load owner data from localStorage and update the UI
    try {
        const ownerData = JSON.parse(localStorage.getItem('ownerUser'));
        
        if (ownerData) {
            // Update the user name display
            const userNameElement = document.getElementById('userName');
            if (userNameElement) {
                userNameElement.textContent = ownerData.ownerName || 'Owner';
            }
            
            // Generate initials for avatar
            const initialsElement = document.getElementById('userInitials');
            if (initialsElement && ownerData.ownerName) {
                const nameParts = ownerData.ownerName.split(' ');
                let initials = '';
                
                if (nameParts.length >= 2) {
                    // Get first letter of first and last name
                    initials = nameParts[0].charAt(0) + nameParts[nameParts.length - 1].charAt(0);
                } else if (nameParts.length === 1) {
                    // If only one name, use first two letters
                    initials = nameParts[0].substring(0, 2);
                } else {
                    initials = 'OU'; // Owner User fallback
                }
                
                initialsElement.textContent = initials.toUpperCase();
            }
            
            // Update business name in the title if needed
            document.title = `${ownerData.businessName || 'Owner'} Dashboard - Smart Fee Management`;

            // Update dashboard header with business type if applicable
            const dashboardHeader = document.querySelector('header h1');
            if (dashboardHeader && ownerData.businessType && ownerData.serviceName) {
                let businessTypeDisplay = ownerData.businessType;
                if (businessTypeDisplay === 'other' && ownerData.otherBusinessType) {
                    businessTypeDisplay = ownerData.otherBusinessType;
                }
                dashboardHeader.textContent = `${ownerData.serviceName} Dashboard`;
            }
        }
    } catch (error) {
        console.error('Error loading owner data:', error);
    }
    
    // Theme toggle functionality
    const htmlElement = document.documentElement;
    const themeToggle = document.getElementById('themeToggle');

    // Check for saved theme preference or respect OS setting
    const savedTheme = localStorage.getItem('theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

    // Apply the right theme
    if (savedTheme === 'dark' || (!savedTheme && systemPrefersDark)) {
        htmlElement.classList.add('dark');
    } else {
        htmlElement.classList.remove('dark');
    }

    // Toggle theme when button is clicked
    themeToggle.addEventListener('click', () => {
        if (htmlElement.classList.contains('dark')) {
            htmlElement.classList.remove('dark');
            localStorage.setItem('theme', 'light');
        } else {
            htmlElement.classList.add('dark');
            localStorage.setItem('theme', 'dark');
        }
    });

    // Mobile sidebar functionality
    const sidebar = document.getElementById('sidebar');
    const toggleSidebarBtn = document.getElementById('toggleSidebar');
    const closeSidebarBtn = document.getElementById('closeSidebar');

    toggleSidebarBtn.addEventListener('click', () => {
        sidebar.classList.toggle('-translate-x-full');
    });

    closeSidebarBtn.addEventListener('click', () => {
        sidebar.classList.add('-translate-x-full');
    });

    // Modal functionality
    const addClientModal = document.getElementById('addClientModal');
    const addClientBtn = document.getElementById('addClientBtn');
    const closeAddClientModal = document.getElementById('closeAddClientModal');
    const cancelAddClient = document.getElementById('cancelAddClient');

    addClientBtn.addEventListener('click', () => {
        addClientModal.classList.remove('hidden');
        gsap.to(addClientModal.querySelector('div > div'), { 
            y: 0, 
            opacity: 1, 
            duration: 0.3,
            ease: 'power2.out',
            clearProps: 'all' 
        });
    });

    const closeModal = () => {
        gsap.to(addClientModal.querySelector('div > div'), { 
            y: -20, 
            opacity: 0, 
            duration: 0.2,
            ease: 'power2.in',
            onComplete: () => {
                addClientModal.classList.add('hidden');
            }
        });
    };

    closeAddClientModal.addEventListener('click', closeModal);
    cancelAddClient.addEventListener('click', closeModal);

    // Function to show toast notifications
    function showToast(type, message) {
        const toast = document.createElement('div');
        toast.className = `fixed top-4 right-4 px-4 py-2 rounded-lg text-white ${
            type === 'success' ? 'bg-green-500' : 
            type === 'error' ? 'bg-red-500' : 
            type === 'warning' ? 'bg-yellow-500' : 'bg-blue-500'
        } shadow-lg z-50 transform transition-all duration-500 opacity-0`;
        
        toast.textContent = message;
        document.body.appendChild(toast);
        
        // Animate in
                setTimeout(() => {
            toast.classList.remove('opacity-0');
            toast.classList.add('opacity-100');
        }, 10);
        
        // Auto remove after 3 seconds
        setTimeout(() => {
            toast.classList.remove('opacity-100');
            toast.classList.add('opacity-0');
            
                setTimeout(() => {
                document.body.removeChild(toast);
            }, 500);
        }, 3000);
    }

    // Add citiesByState object for city-state filtering
    const citiesByState = {
        "andhra-pradesh": ["Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Kurnool", "Rajahmundry", "Tirupati"],
        "arunachal-pradesh": ["Itanagar", "Naharlagun", "Pasighat", "Tawang"],
        "assam": ["Guwahati", "Silchar", "Dibrugarh", "Jorhat", "Nagaon", "Tinsukia"],
        "bihar": ["Patna", "Gaya", "Bhagalpur", "Muzaffarpur", "Darbhanga", "Arrah"],
        "chhattisgarh": ["Raipur", "Bhilai", "Bilaspur", "Korba", "Durg"],
        "goa": ["Panaji", "Margao", "Vasco da Gama", "Mapusa", "Ponda"],
        "gujarat": ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar"],
        "haryana": ["Faridabad", "Gurgaon", "Panipat", "Ambala", "Yamunanagar", "Rohtak"],
        "himachal-pradesh": ["Shimla", "Dharamshala", "Mandi", "Solan", "Kullu"],
        "jharkhand": ["Ranchi", "Jamshedpur", "Dhanbad", "Bokaro", "Hazaribagh"],
        "karnataka": ["Bangalore", "Mysore", "Hubli", "Mangalore", "Belgaum", "Gulbarga"],
        "kerala": ["Thiruvananthapuram", "Kochi", "Kozhikode", "Thrissur", "Kollam"],
        "madhya-pradesh": ["Indore", "Bhopal", "Jabalpur", "Gwalior", "Ujjain"],
        "maharashtra": ["Mumbai", "Pune", "Nagpur", "Thane", "Nashik", "Aurangabad"],
        "manipur": ["Imphal", "Bishnupur", "Thoubal", "Churachandpur"],
        "meghalaya": ["Shillong", "Tura", "Jowai", "Nongpoh"],
        "mizoram": ["Aizawl", "Lunglei", "Champhai", "Kolasib"],
        "nagaland": ["Kohima", "Dimapur", "Mokokchung", "Wokha", "Tuensang"],
        "odisha": ["Bhubaneswar", "Cuttack", "Rourkela", "Berhampur", "Sambalpur"],
        "punjab": ["Ludhiana", "Amritsar", "Jalandhar", "Patiala", "Bathinda"],
        "rajasthan": ["Jaipur", "Jodhpur", "Udaipur", "Kota", "Bikaner", "Ajmer"],
        "sikkim": ["Gangtok", "Namchi", "Mangan", "Gyalshing"],
        "tamil-nadu": ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem"],
        "telangana": ["Hyderabad", "Warangal", "Nizamabad", "Karimnagar", "Khammam"],
        "tripura": ["Agartala", "Udaipur", "Dharmanagar", "Kailashahar"],
        "uttar-pradesh": ["Lucknow", "Kanpur", "Varanasi", "Agra", "Meerut", "Allahabad"],
        "uttarakhand": ["Dehradun", "Haridwar", "Rishikesh", "Haldwani", "Roorkee"],
        "west-bengal": ["Kolkata", "Howrah", "Durgapur", "Asansol", "Siliguri"]
    };
    
    // Function to update cities dropdown based on selected state
    function updateCitiesInModal() {
        const stateSelect = document.getElementById('clientState');
        const citySelect = document.getElementById('clientCity');
        
        if (!stateSelect || !citySelect) return;
        
        // Clear existing options
        citySelect.innerHTML = '<option disabled selected>Select City</option>';
        
        const selectedState = stateSelect.value;
        
        if (selectedState && citiesByState[selectedState]) {
            citiesByState[selectedState].forEach(city => {
                const option = document.createElement('option');
                option.value = city.toLowerCase().replace(/\s+/g, '-');
                option.textContent = city;
                citySelect.appendChild(option);
            });
        }
    }
    
    // Initialize city dropdown when state is changed
    const stateSelect = document.getElementById('clientState');
    if (stateSelect) {
        stateSelect.addEventListener('change', updateCitiesInModal);
    }
    
    // Form validation for password match
    if (document.getElementById('clientPassword') && document.getElementById('clientConfirmPassword')) {
        const passwordInput = document.getElementById('clientPassword');
        const confirmInput = document.getElementById('clientConfirmPassword');
        
        confirmInput.addEventListener('input', function() {
            if (passwordInput.value !== confirmInput.value) {
                confirmInput.setCustomValidity("Passwords don't match");
            } else {
                confirmInput.setCustomValidity('');
            }
        });
        
        passwordInput.addEventListener('input', function() {
            if (confirmInput.value && passwordInput.value !== confirmInput.value) {
                confirmInput.setCustomValidity("Passwords don't match");
            } else {
                confirmInput.setCustomValidity('');
            }
        });
    }
    
    // Update form submission to send all fields to server and store in clientRegisters table
    if (document.getElementById('addClientForm')) {
        const addClientForm = document.getElementById('addClientForm');
        
        addClientForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Validate password match
            const password = document.getElementById('clientPassword').value;
            const confirmPassword = document.getElementById('clientConfirmPassword').value;
            
            if (password !== confirmPassword) {
                showToast('error', "Passwords don't match");
                return;
            }
            
            // Show loading state
            const submitButton = addClientForm.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.innerHTML;
            submitButton.disabled = true;
            submitButton.innerHTML = '<svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Adding client...';
            
            // Get form data
            const formData = new FormData(addClientForm);
            const formDataObj = {};
            
            // Convert FormData to plain object
            formData.forEach((value, key) => {
                formDataObj[key] = value;
            });
            
            // Add owner ID from token if not already included
            const token = localStorage.getItem('ownerToken');
            if (token) {
                // Parse the JWT token to get owner ID
                try {
                    const base64Url = token.split('.')[1];
                    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
                    const payload = JSON.parse(window.atob(base64));
                    if (payload.id) {
                        formDataObj.ownerId = payload.id;
                    }
                } catch (error) {
                    console.error('Error parsing token:', error);
                }
            }
            
            // Use fetch API instead of form submission to prevent redirect
            fetch('http://localhost:3000/api/register-client', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formDataObj)
            })
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(text || 'Failed to register client');
                    });
                }
                return response.json();
            })
            .then(data => {
                // Success
                closeModal();
                showToast('success', 'Client added successfully to clientRegisters database');
                
                // Reset form
                addClientForm.reset();
                
                // Attempt to refresh client list
                try {
                    fetchClients();
                } catch(e) {
                    console.log('Could not refresh client list after registration');
                }
            })
            .catch(error => {
                console.error('Registration error:', error);
                showToast('error', error.message || 'Failed to register client');
            })
            .finally(() => {
                // Reset button state
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
            });
        });
    }
    
    // Function to fetch and display clients
    async function fetchClients() {
        try {
            // Basic elements
            const clientTable = document.getElementById('clientTable');
            const clientCount = document.getElementById('clientCount');
            
            // Empty state HTML
            const emptyHTML = `<tr><td colspan="6" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">No approved clients found</td></tr>`;
            
            // Get owner token
            const token = localStorage.getItem('ownerToken');
            if (!token) {
                console.error('No auth token found');
                clientTable.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">Authentication error - please log in again</td></tr>`;
                return;
            }
            
            // Show loading state
            clientTable.innerHTML = `
                <tr>
                    <td colspan="6" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">
                        <div class="flex items-center justify-center">
                            <svg class="animate-spin h-5 w-5 mr-3 text-indigo-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Loading approved clients...
                        </div>
                    </td>
                </tr>
            `;
            
            // Fetch approved requests from the server
            console.log('Fetching approved requests...');
            const response = await fetch('http://localhost:3000/api/clients', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            console.log('Response status:', response.status);
            
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            
            const clients = await response.json();
            console.log('API response:', clients);
            
            // Update count
            if (clientCount) clientCount.textContent = clients.length || '0';
            
            // Handle empty results
            if (!clients || clients.length === 0) {
                clientTable.innerHTML = emptyHTML;
                return;
            }
            
            // Add clients to table
            clientTable.innerHTML = '';
            try {
            clients.forEach(client => {
                    console.log('Processing client:', client);
                    
                    // Format the plan details
                    const planDetails = `${client.planType} (₹${client.planAmount || 0})`;
                    
                    // Calculate days remaining until next payment
                    let statusClass = 'bg-green-100 text-green-800';
                    let statusText = 'Active';
                    
                    try {
                        if (client.nextDueDate) {
                            const nextDueDate = new Date(client.nextDueDate);
                            const today = new Date();
                            
                            // Reset hours to compare only dates
                            today.setHours(0, 0, 0, 0);
                            
                            // Calculate days remaining
                            const diffTime = nextDueDate.getTime() - today.getTime();
                            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                            
                            if (diffDays < 0) {
                                // Payment overdue
                                statusClass = 'bg-red-100 text-red-800';
                                statusText = `Overdue by ${Math.abs(diffDays)} days`;
                            } else if (diffDays === 0) {
                                // Due today
                                statusClass = 'bg-yellow-100 text-yellow-800';
                                statusText = 'Due today';
                            } else if (diffDays <= 7) {
                                // Due within a week
                                statusClass = 'bg-yellow-100 text-yellow-800';
                                statusText = `Due in ${diffDays} days`;
                            } else {
                                // Due later
                                statusClass = 'bg-green-100 text-green-800';
                                statusText = `Due in ${diffDays} days`;
                            }
                            
                            console.log(`Client ${client.fullname}: Next due date: ${nextDueDate.toDateString()}, Days remaining: ${diffDays}`);
                        } else {
                            // No next due date available
                            statusClass = 'bg-gray-100 text-gray-800';
                            statusText = 'No due date';
                        }
                    } catch (statusError) {
                        console.error('Error calculating payment status:', statusError);
                        statusClass = 'bg-gray-100 text-gray-800';
                        statusText = 'Status error';
                    }
                    
                    // Format the approval date 
                    const approvalDate = client.approvedDate 
                        ? new Date(client.approvedDate).toLocaleDateString('en-GB') 
                        : 'N/A';
                    
                    // Format the next due date based on planType
                    let nextDueDate = 'N/A';
                    try {
                        if (client.nextDueDate) {
                            // Use existing next due date if available
                            const date = new Date(client.nextDueDate);
                            if (!isNaN(date.getTime())) {
                                nextDueDate = date.toLocaleDateString('en-GB');
                            }
                        } else if (client.approvedDate) {
                            // Approval date is the next due date if nextDueDate isn't explicitly set
                            const date = new Date(client.approvedDate);
                            if (!isNaN(date.getTime())) {
                                nextDueDate = date.toLocaleDateString('en-GB');
                            }
                        } else if (client.lastPaymentDate) {
                            // If we have neither nextDueDate nor approvedDate, calculate from lastPaymentDate
                            const paymentDate = new Date(client.lastPaymentDate);
                            if (!isNaN(paymentDate.getTime())) {
                                let calculatedDate = new Date(paymentDate);
                                
                                // Calculate next due date based on plan type
                                switch(client.planType.toLowerCase()) {
                                    case 'monthly':
                                        calculatedDate.setMonth(paymentDate.getMonth() + 1);
                                        break;
                                    case 'quarterly':
                                        calculatedDate.setMonth(paymentDate.getMonth() + 3);
                                        break;
                                    case 'half-yearly':
                                        calculatedDate.setMonth(paymentDate.getMonth() + 6);
                                        break;
                                    case 'yearly':
                                        calculatedDate.setFullYear(paymentDate.getFullYear() + 1);
                                        break;
                                }
                                
                                nextDueDate = calculatedDate.toLocaleDateString('en-GB');
                            }
                        }
                    } catch (dateError) {
                        console.error('Error formatting next due date:', dateError);
                        nextDueDate = 'Error';
                    }

                    // Check for requestId 
                    const requestId = client.requestId || client.id;
                    
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="flex items-center">
                            <div>
                                <div class="text-sm font-medium text-gray-900 dark:text-white">${client.fullname}</div>
                            </div>
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                        <a href="mailto:${client.email}" class="hover:text-indigo-500 dark:hover:text-indigo-400 truncate">
                            ${client.email || 'No email'}
                        </a>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">${client.mobile}</td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClass} dark:bg-opacity-30">${statusText}</span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                        ${client.planType || 'Monthly'}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">${approvalDate}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">${nextDueDate}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div class="flex justify-end space-x-2">
                            <button class="remind-btn p-2 rounded-lg text-yellow-600" data-client-id="${client.id}" data-request-id="${requestId}" data-client-email="${client.email}" title="Send reminder">📝</button>
                            <button class="mark-paid-btn p-2 rounded-lg text-green-600" data-client-id="${client.id}" data-request-id="${requestId}" data-plan-type="${client.planType || 'monthly'}" title="Mark as paid">✓</button>
                            <button class="remove-client-btn p-2 rounded-lg text-red-600" data-client-id="${client.id}" data-request-id="${requestId}" title="Remove client">✕</button>
                        </div>
                    </td>
                `;
                clientTable.appendChild(row);
            });
            
                // Add event listeners - call setupClientActionButtons explicitly
                console.log('Setting up client action buttons after refresh');
            setupClientActionButtons();
            } catch (error) {
                console.error('Error processing client data:', error);
                clientTable.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">Error processing client data: ${error.message}</td></tr>`;
            }
        } catch (e) {
            console.error('Client display error:', e);
            
            // Ensure the client table shows something even if there's an error
            const clientTable = document.getElementById('clientTable');
            if (clientTable) {
                clientTable.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">Error loading client data: ${e.message}</td></tr>`;
            }
        }
    }
    
    // Function to set up event listeners for client action buttons
    function setupClientActionButtons() {
        try {
            console.log('Setting up client action buttons');
            
            // Count the number of buttons we're setting up
            const reminderButtons = document.querySelectorAll('.remind-btn');
            const paymentButtons = document.querySelectorAll('.mark-paid-btn');
            const removeButtons = document.querySelectorAll('.remove-client-btn');
            
            console.log(`Found ${reminderButtons.length} reminder buttons, ${paymentButtons.length} payment buttons, and ${removeButtons.length} remove buttons`);
            
            // Remind button click handler
            reminderButtons.forEach((button, index) => {
                try {
            button.addEventListener('click', async (e) => {
                        // Get the necessary data for the reminder
                        const requestId = e.currentTarget ? e.currentTarget.getAttribute('data-request-id') : button.getAttribute('data-request-id');
                        const clientEmail = e.currentTarget ? e.currentTarget.getAttribute('data-client-email') : button.getAttribute('data-client-email');
                        
                        // Get client name from the row
                        const parentRow = button.closest('tr');
                        let clientName = "this client";
                        if (parentRow) {
                            const nameCell = parentRow.cells[0];
                            if (nameCell) {
                                const nameDiv = nameCell.querySelector('.text-sm.font-medium');
                                if (nameDiv) {
                                    clientName = nameDiv.textContent.trim();
                                }
                            }
                        }
                        
                        console.log('Send reminder for request:', requestId);
                        console.log('Client email from data attribute:', clientEmail);
                        
                        // Confirmation dialog
                        if (!confirm(`Send a payment reminder email to ${clientName}${clientEmail ? ` (${clientEmail})` : ''}?`)) {
                            return;
                        }
                        
                        // Show loading indicator
                        button.disabled = true;
                        const originalText = button.innerHTML;
                        button.innerHTML = '⏳';
                        
                        try {
                            const token = localStorage.getItem('ownerToken');
                            if (!token) {
                                showToast('error', 'Authentication error. Please log in again.');
                                return;
                            }
                            
                            // Call API to send reminder
                            const response = await fetch(`http://localhost:3000/api/requests/${requestId}/remind`, {
                        method: 'POST',
                        headers: {
                                    'Authorization': `Bearer ${token}`,
                                    'Content-Type': 'application/json'
                                }
                            });
                            
                            console.log('Reminder API response status:', response.status);
                            
                            // Handle response
                            if (response.ok) {
                                const data = await response.json();
                                console.log('Reminder API success response:', data);
                                showToast('success', `Payment reminder email sent to ${data.email || clientEmail || 'the client'}`);
                                
                                // Show success icon briefly
                                button.innerHTML = '✅';
                                setTimeout(() => {
                                    button.innerHTML = originalText;
                                    button.disabled = false;
                                }, 1500);
                            } else {
                                const errorData = await response.json();
                                showToast('error', errorData.message || 'Failed to send reminder');
                                
                                // Reset button
                                button.innerHTML = originalText;
                                button.disabled = false;
                            }
                } catch (error) {
                    console.error('Error sending reminder:', error);
                            showToast('error', 'Failed to send reminder: ' + error.message);
                            
                            // Reset button
                            button.innerHTML = originalText;
                            button.disabled = false;
                        }
                    });
                    
                    console.log(`Set up reminder button ${index + 1}`);
                } catch (buttonError) {
                    console.error(`Error setting up reminder button ${index + 1}:`, buttonError);
                }
            });
            
            // Mark as paid button click handler
            paymentButtons.forEach((button, index) => {
                try {
                    // Use the same handler we defined earlier
            button.addEventListener('click', async (e) => {
                        try {
                            // Prevent default behavior if it's a link
                            if (e && e.preventDefault) {
                                e.preventDefault();
                            }
                            
                            // Safely get the request ID, even if the event object is problematic
                            let requestId;
                            if (e && e.currentTarget) {
                                requestId = e.currentTarget.getAttribute('data-request-id');
                            } else if (this && this.getAttribute) {
                                requestId = this.getAttribute('data-request-id');
                            } else {
                                // Fallback to button if event target is unreliable
                                requestId = button.getAttribute('data-request-id');
                            }
                            
                            console.log('Mark as paid for request:', requestId);
                            
                            if (!requestId) {
                                showToast('error', 'Invalid request ID');
                                return;
                            }
                            
                            const token = localStorage.getItem('ownerToken');
                            if (!token) {
                                showToast('error', 'Authentication error. Please log in again.');
                                return;
                            }
                            
                            // Find the row to get the current nextDueDate and planType if available
                            const parentRow = button.closest('tr');
                            let nextDueDate = null;
                            let planType = 'monthly'; // Default plan type
                            
                            if (parentRow) {
                                // Get the next due date from the table row (5th column)
                                const nextDueDateCell = parentRow.cells[5]; // 0-based index
                                if (nextDueDateCell) {
                                    const nextDueDateText = nextDueDateCell.textContent.trim();
                                    if (nextDueDateText && nextDueDateText !== 'N/A' && nextDueDateText !== 'Error') {
                                        try {
                                            // Try to parse the displayed date back to ISO format
                                            const dateParts = nextDueDateText.split('/');
                                            if (dateParts.length === 3) {
                                                // Format: DD/MM/YYYY (en-GB format)
                                                const day = parseInt(dateParts[0]);
                                                const month = parseInt(dateParts[1]) - 1; // 0-based month
                                                const year = parseInt(dateParts[2]);
                                                
                                                if (!isNaN(month) && !isNaN(day) && !isNaN(year)) {
                                                    const date = new Date(year, month, day);
                                                    nextDueDate = date.toISOString();
                                                    console.log(`Found next due date: ${nextDueDate}`);
                                                }
                                            }
                                        } catch (dateError) {
                                            console.error('Error parsing next due date:', dateError);
                                        }
                                    }
                                }
                                
                                // Try to get plan type from status cell text
                                const statusCell = parentRow.cells[3]; // 0-based index for status
                                if (statusCell) {
                                    const statusText = statusCell.textContent.toLowerCase().trim();
                                    
                                    // Extract planType based on status text
                                    if (statusText.includes('quarterly')) {
                                        planType = 'quarterly';
                                    } else if (statusText.includes('half-yearly')) {
                                        planType = 'half-yearly';
                                    } else if (statusText.includes('yearly')) {
                                        planType = 'yearly';
                                    } else {
                                        // Default to monthly if not found
                                        planType = 'monthly';
                                    }
                                    
                                    console.log(`Determined plan type from row: ${planType}`);
                                }
                                
                                // Fall back to data-plan-type attribute if present on the button
                                const buttonPlanType = button.getAttribute('data-plan-type');
                                if (buttonPlanType) {
                                    planType = buttonPlanType;
                                    console.log(`Using plan type from button attribute: ${planType}`);
                                }
                            }
                            
                            console.log(`Sending payment update with nextDueDate: ${nextDueDate}, planType: ${planType}`);
                            
                            // Call API to mark payment
                            const response = await fetch(`http://localhost:3000/api/requests/${requestId}/payment`, {
                        method: 'POST',
                        headers: {
                                    'Authorization': `Bearer ${token}`,
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    status: 'paid',
                                    date: new Date().toISOString(),
                                    lastPaymentDate: nextDueDate, // Pass the current nextDueDate as lastPaymentDate
                                    planType: planType // Include the plan type in the request
                                })
                            });
                            
                            // Process response
                            if (response.ok) {
                                // Show success message
                                showToast('success', 'Payment marked as received.');
                                
                                // Refresh client list to update the UI
                    fetchClients();
                            } else {
                                // Handle error response
                                const errorData = await response.json();
                                showToast('error', errorData.message || 'Failed to mark payment');
                            }
                } catch (error) {
                            console.error('Error in mark as paid button handler:', error);
                            showToast('error', 'Failed to mark payment: ' + (error.message || 'Unknown error'));
                            
                            // Still try to refresh clients
                            fetchClients();
                        }
                    });
                    
                    console.log(`Set up payment button ${index + 1}`);
                } catch (buttonError) {
                    console.error(`Error setting up payment button ${index + 1}:`, buttonError);
                }
            });
            
            // Remove client button click handler
            removeButtons.forEach((button, index) => {
                try {
            button.addEventListener('click', async (e) => {
                        if (!confirm('Are you sure you want to remove this client?')) {
                            return;
                        }
                        
                        // Get request ID safely
                        let requestId;
                        if (e && e.currentTarget) {
                            requestId = e.currentTarget.getAttribute('data-request-id');
                        } else {
                            requestId = button.getAttribute('data-request-id');
                        }
                        
                        console.log('Remove request:', requestId);
                        
                        if (!requestId) {
                            showToast('error', 'Invalid request ID');
                            return;
                        }
                        
                        try {
                            const token = localStorage.getItem('ownerToken');
                            if (!token) {
                                showToast('error', 'Authentication error. Please log in again.');
                                return;
                            }
                            
                            // Call API to remove request
                            const response = await fetch(`http://localhost:3000/api/requests/${requestId}`, {
                            method: 'DELETE',
                            headers: {
                                    'Authorization': `Bearer ${token}`
                                }
                            });
                            
                            if (response.ok) {
                                showToast('success', 'Client removed successfully');
                                // Refresh the client list
                        fetchClients();
                            } else {
                                const errorData = await response.json();
                                showToast('error', errorData.message || 'Failed to remove client');
                            }
                    } catch (error) {
                        console.error('Error removing client:', error);
                            showToast('error', 'Failed to remove client: ' + error.message);
                        }
                    });
                    
                    console.log(`Set up remove button ${index + 1}`);
                } catch (buttonError) {
                    console.error(`Error setting up remove button ${index + 1}:`, buttonError);
                }
            });
            
            console.log('All client action buttons set up successfully');
        } catch (setupError) {
            console.error('Error setting up client action buttons:', setupError);
        }
    }
    
    // Function to fetch and display pending client approvals
    async function fetchPendingClients() {
        try {
            // Get owner token
            const token = localStorage.getItem('ownerToken');
            if (!token) {
                console.error('No auth token found');
                return;
            }

            const response = await fetch('http://localhost:3000/api/clients/pending', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            if (!response.ok) {
                console.log('Error fetching pending clients:', response.status);
                
                // Display empty state
                const pendingClientsTable = document.getElementById('pendingClientsTable');
                if (pendingClientsTable) {
                    pendingClientsTable.innerHTML = `
                        <tr>
                            <td colspan="4" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">
                                No pending client approvals
                            </td>
                        </tr>
                    `;
                }
                return;
            }
            
            const pendingClients = await response.json();
            const pendingClientsTable = document.getElementById('pendingClientsTable');
            
            if (pendingClientsTable) {
                // Clear existing rows
                pendingClientsTable.innerHTML = '';
                
                // Display empty state by default
                if (!pendingClients || pendingClients.length === 0) {
                    pendingClientsTable.innerHTML = `
                        <tr>
                            <td colspan="4" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">
                                No pending client approvals
                            </td>
                        </tr>
                    `;
                    return;
                }
                
                // Add pending client rows
                pendingClients.forEach(client => {
                    const registrationDate = client.registrationDate 
                        ? new Date(client.registrationDate).toLocaleDateString() 
                        : 'N/A';
                        
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900 dark:text-white">${client.fullname}</div>
                                    <div class="text-sm text-gray-500 dark:text-gray-400">${client.email}</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">${client.mobile}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">${registrationDate}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <div class="flex justify-end space-x-2">
                                <button class="approve-client-btn px-3 py-1 rounded-lg bg-green-500 text-white hover:bg-green-600 transition" data-client-id="${client.id}">
                                    Approve
                                </button>
                                <button class="reject-client-btn px-3 py-1 rounded-lg bg-red-500 text-white hover:bg-red-600 transition" data-client-id="${client.id}">
                                    Reject
                                </button>
                            </div>
                        </td>
                    `;
                    pendingClientsTable.appendChild(row);
                });
                
                // Set up event listeners for approval buttons
                setupApprovalButtons();
            }
        } catch (error) {
            console.error('Error fetching pending clients:', error);
            
            // Display empty state
            const pendingClientsTable = document.getElementById('pendingClientsTable');
            if (pendingClientsTable) {
                pendingClientsTable.innerHTML = `
                    <tr>
                        <td colspan="4" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">
                            No pending client approvals
                        </td>
                    </tr>
                `;
            }
        }
    }
    
    // Setup event listeners for approval buttons
    function setupApprovalButtons() {
        // Approve button
        document.querySelectorAll('.approve-client-btn').forEach(button => {
            button.addEventListener('click', async (e) => {
                const clientId = e.currentTarget.dataset.clientId;
                try {
                    const token = localStorage.getItem('ownerToken');
                    const response = await fetch(`http://localhost:3000/api/clients/${clientId}/approve`, {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${token}`
                        }
                    });
                    
                    if (!response.ok) {
                        throw new Error('Failed to approve client');
                    }
                    
                    showToast('success', 'Client approved successfully');
                    // Refresh pending clients list
                    
                    // Refresh client list to show new client
                    fetchClients();
                } catch (error) {
                    console.error('Error approving client:', error);
                    showToast('error', 'Failed to approve client');
                }
            });
        });
        
        // Reject button
        document.querySelectorAll('.reject-client-btn').forEach(button => {
            button.addEventListener('click', async (e) => {
                if (confirm('Are you sure you want to reject this client?')) {
                    const clientId = e.currentTarget.dataset.clientId;
                    try {
                        const token = localStorage.getItem('ownerToken');
                        const response = await fetch(`http://localhost:3000/api/clients/${clientId}/reject`, {
                            method: 'POST',
                            headers: {
                                'Authorization': `Bearer ${token}`
                            }
                        });
                        
                        if (!response.ok) {
                            throw new Error('Failed to reject client');
                        }
                        
                        showToast('success', 'Client rejected successfully');
                        // Refresh pending clients list
                        
                    } catch (error) {
                        console.error('Error rejecting client:', error);
                        showToast('error', 'Failed to reject client');
                    }
                }
            });
        });
    }
    
    // Function to fetch and display payment history
    async function fetchPaymentHistory() {
        try {
            const response = await fetch('/api/payments/recent', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('ownerToken')}`
                }
            });
            
            if (!response.ok) {
                // Just log the error, don't show toast
                console.log('Payment history API not available yet');
                return;
            }
            
            const payments = await response.json();
            const paymentHistoryTable = document.getElementById('paymentHistoryTable');
            
            if (paymentHistoryTable) {
                // Clear existing rows
                paymentHistoryTable.innerHTML = '';
                
                // Display empty state by default
                if (!payments || payments.length === 0) {
                    const emptyRow = document.createElement('tr');
                    emptyRow.innerHTML = `
                        <td colspan="4" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">
                            No recent payment history
                        </td>
                    `;
                    paymentHistoryTable.appendChild(emptyRow);
                    return;
                }
                
                // Add payment history rows with simplified display
                payments.forEach(payment => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <div class="ml-3">
                                    <div class="text-sm font-medium text-gray-900 dark:text-white">${payment.clientName}</div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">${payment.date}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">₹${payment.amount}</td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">${payment.status}</span>
                        </td>
                    `;
                    paymentHistoryTable.appendChild(row);
                });
            }
        } catch (error) {
            // Just log error to console, no toast
            console.log('Payment history not available yet');
            
            // Display empty state anyway
            const paymentHistoryTable = document.getElementById('paymentHistoryTable');
            if (paymentHistoryTable) {
                paymentHistoryTable.innerHTML = `
                    <tr>
                        <td colspan="4" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">
                            No recent payment history
                        </td>
                    </tr>
                `;
            }
        }
    }
    
    // Load all data when page loads
    setTimeout(() => {
        fetchClients();
        
        // Calculate and display yearly revenue
        calculateYearlyRevenue();
    }, 500); // Small delay to ensure DOM is fully loaded

    // Add event listener for the Payments sidebar link
    const paymentsLink = document.getElementById('paymentsLink');
    if (paymentsLink) {
        paymentsLink.addEventListener('click', function(e) {
            e.preventDefault(); // Prevent navigation
            const paymentSettingsModal = document.getElementById('paymentSettingsModal');
            if (paymentSettingsModal) {
                paymentSettingsModal.classList.remove('hidden');
                gsap.to(paymentSettingsModal.querySelector('div > div'), {
                    y: 0,
                    opacity: 1,
                    duration: 0.3,
                    ease: 'power2.out',
                    clearProps: 'all'
                });
                
                // Load payment settings when modal is opened
                loadPaymentSettings();
            }
        });
    }

    // Payment Settings Functionality
    document.addEventListener('DOMContentLoaded', function() {
        // References to payment settings elements
        const paymentSettingsModal = document.getElementById('paymentSettingsModal');
        const paymentSettingsForm = document.getElementById('paymentSettingsForm');
        const serviceFeeInput = document.getElementById('serviceFee');
        const savePaymentSettingsBtn = document.getElementById('savePaymentSettingsBtn');
        const cancelPaymentSettings = document.getElementById('cancelPaymentSettings');
        const closePaymentSettingsModal = document.getElementById('closePaymentSettingsModal');
        const addCustomOptionBtn = document.getElementById('addCustomOption');
        
        // Initialize global payment settings array
        window.currentPaymentSettings = window.currentPaymentSettings || [];
        
        // Add event listener for opening the payment settings modal
        const openPaymentSettingsBtn = document.getElementById('openPaymentSettingsBtn');
        if (openPaymentSettingsBtn) {
            openPaymentSettingsBtn.addEventListener('click', function() {
                if (paymentSettingsModal) {
                    paymentSettingsModal.classList.remove('hidden');
                    loadPaymentSettings();
                }
            });
        }
        
        // Add event listener for closing the payment settings modal
        if (closePaymentSettingsModal) {
            closePaymentSettingsModal.addEventListener('click', function() {
                paymentSettingsModal.classList.add('hidden');
            });
        }
        
        if (cancelPaymentSettings) {
            cancelPaymentSettings.addEventListener('click', function() {
                paymentSettingsModal.classList.add('hidden');
            });
        }
        
        // Add event listener for custom payment option button
        if (addCustomOptionBtn) {
            addCustomOptionBtn.addEventListener('click', addPaymentOption);
        }
        
        // Add event listener for form submission
        if (paymentSettingsForm) {
            paymentSettingsForm.addEventListener('submit', async function(e) {
                e.preventDefault();
                
                // Get the service fee value
                const serviceFee = serviceFeeInput.value.trim();
                const fee = Number(serviceFee);
                
                // Validate service fee
                if (!serviceFee || isNaN(fee) || fee <= 0) {
                    showToast('Please enter a valid service fee amount', false);
                    return;
                }
                
                // Ensure we have payment settings
                if (!window.currentPaymentSettings || window.currentPaymentSettings.length === 0) {
                    showToast('Please add at least one payment setting', false);
                    return;
                }
                
                // Show loading state
                savePaymentSettingsBtn.disabled = true;
                const originalButtonText = savePaymentSettingsBtn.innerHTML;
                savePaymentSettingsBtn.innerHTML = '<svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Saving...';
                
                try {
                    // Get the token from localStorage
                    const token = localStorage.getItem('ownerToken');
                    if (!token) {
                        throw new Error('Not authenticated');
                    }
                    
                    // Create a direct key-value object for payment settings
                    const paymentOptions = {};
                    
                    // Format payment settings
                    const formattedPaymentSettings = window.currentPaymentSettings.map(setting => {
                        if (typeof setting === 'object' && setting.name) {
                            // Make sure amount is a valid number
                            const amount = Number(setting.amount) || 0;
                            
                            // Add to direct key-value object
                            const normalizedName = setting.name.toLowerCase().replace(/[-\s]/g, '');
                            paymentOptions[normalizedName] = amount;
                            
                            return {
                                name: setting.name,
                                amount: amount
                            };
                        }
                        return null;
                    }).filter(setting => setting !== null);
                    
                    // Extract all payment setting names
                    const allPaymentSettingNames = formattedPaymentSettings.map(setting => setting.name);
                    const paymentSetting = allPaymentSettingNames.join(',');
                    
                    // Get standard payment option amounts
                    const monthlyAmount = document.getElementById('monthlyAmount')?.value || 0;
                    const quarterlyAmount = document.getElementById('quarterlyAmount')?.value || 0;
                    const halfYearlyAmount = document.getElementById('halfYearlyAmount')?.value || 0;
                    const yearlyAmount = document.getElementById('yearlyAmount')?.value || 0;
                    
                    // Get the discount strategy
                    const discountStrategy = document.getElementById('discountStrategy')?.value || 'default';
                    
                    // Prepare the data to send
                    const formData = {
                        serviceFee: fee,
                        paymentSettings: formattedPaymentSettings,
                        paymentSetting: paymentSetting,
                        monthlyAmount,
                        quarterlyAmount,
                        halfYearlyAmount,
                        yearlyAmount,
                        paymentOptions,
                        discountStrategy
                    };
                    
                    // Send the data to the API
                    const response = await fetch('http://localhost:3000/api/owner/payment-settings', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${token}`
                        },
                        body: JSON.stringify(formData)
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        showToast('Payment settings updated successfully');
                        // Close the modal
                        paymentSettingsModal.classList.add('hidden');
                    } else {
                        throw new Error(data.message || 'Failed to update payment settings');
                    }
                } catch (error) {
                    console.error('Error updating payment settings:', error);
                    showToast(error.message || 'Failed to update payment settings', false);
                } finally {
                    // Reset button state
                    savePaymentSettingsBtn.disabled = false;
                    savePaymentSettingsBtn.innerHTML = originalButtonText;
                }
            });
        }
    });

    // Function to add a new payment option
    function addPaymentOption() {
        // Get name, days, and amount from form
        const paymentOptionName = document.getElementById('newPaymentOptionName').value;
        const paymentOptionDays = document.getElementById('newPaymentOptionDays').value;
        const paymentOptionAmount = document.getElementById('newPaymentOptionAmount').value;
        
        // Validate inputs
        if (!paymentOptionName.trim()) {
            showToast('Please enter a valid payment option name', false);
            return;
        }
        
        const days = Number(paymentOptionDays);
        if (isNaN(days) || days < 1) {
            showToast('Please enter a valid number of days (minimum 1)', false);
            return;
        }
        
        const amount = Number(paymentOptionAmount);
        if (isNaN(amount) || amount < 0) {
            showToast('Please enter a valid payment amount', false);
            return;
        }
        
        // Create payment option object
        const newSetting = {
            name: paymentOptionName.trim(),
            days: days,
            amount: amount
        };
        
        // Initialize currentPaymentSettings if not already done
        if (!window.currentPaymentSettings) {
            window.currentPaymentSettings = [];
        }
        
        // Check if this payment option already exists
        const existingIndex = window.currentPaymentSettings.findIndex(s => 
            s.name && s.name.toLowerCase() === newSetting.name.toLowerCase()
        );
        
        // Update or add to current payment settings
        if (existingIndex >= 0) {
            // Update existing item
            window.currentPaymentSettings[existingIndex].days = newSetting.days;
            window.currentPaymentSettings[existingIndex].amount = newSetting.amount;
            showToast(`Updated payment option: ${newSetting.name}`);
        } else {
            // Add new item
            window.currentPaymentSettings.push(newSetting);
            showToast(`Added payment option: ${newSetting.name}`);
        }
        
        // Render the updated list
        renderPaymentSettings();
        
        // Clear form fields
        document.getElementById('newPaymentOptionName').value = '';
        document.getElementById('newPaymentOptionDays').value = '';
        document.getElementById('newPaymentOptionAmount').value = '';
    }

    // Function to load payment settings from the server
    async function loadPaymentSettings() {
        try {
            const token = localStorage.getItem('ownerToken');
            if (!token) {
                throw new Error('Not authenticated');
            }

            // Clear current payment options
            const container = document.getElementById('paymentSettingsContainer');
            container.innerHTML = '<div class="p-3 text-center text-gray-500 dark:text-gray-400 col-span-2"><div class="animate-pulse">Loading payment options...</div></div>';

            const response = await fetch('http://localhost:3000/api/owner/payment-settings', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            const data = await response.json();
            
            if (data.success) {
                // The server returns paymentSettings object containing all settings
                const settings = data.paymentSettings;
                
                // Clear the container
                container.innerHTML = '';
                
                // Initialize the global currentPaymentSettings array
                window.currentPaymentSettings = settings.paymentSettings && Array.isArray(settings.paymentSettings) 
                    ? settings.paymentSettings 
                    : [];
                
                // Show all standard payment options
                const standardOptions = [
                    { period: 'monthly', label: 'per month', color: 'green' },
                    { period: 'quarterly', label: 'per 3 months', color: 'blue' },
                    { period: 'halfYearly', label: 'per 6 months', color: 'purple' },
                    { period: 'yearly', label: 'per year', color: 'orange' }
                ];
                
                // Create each standard payment option element
                for (const option of standardOptions) {
                    const amount = settings[option.period + 'Amount'] || 0;
                    container.appendChild(createPaymentOptionElement(
                        option.period, 
                        amount, 
                        option.label, 
                        option.color
                    ));
                }
                
                // Also update the service fee input field if it exists
                const serviceFeeInput = document.getElementById('serviceFee');
                if (serviceFeeInput) {
                    serviceFeeInput.value = settings.serviceFee || 0;
                }
                
                // Update discount strategy selection if available
                const discountStrategySelect = document.getElementById('discountStrategy');
                if (discountStrategySelect && settings.discountStrategy) {
                    // Set the dropdown to the stored value, or default to "default"
                    const strategy = settings.discountStrategy || 'default';
                    discountStrategySelect.value = strategy;
                }
                
                // Render custom payment options
                renderPaymentSettings();
            } else {
                throw new Error(data.message || 'Failed to load payment settings');
            }
        } catch (error) {
            console.error('Error loading payment settings:', error);
            showToast(error.message || 'Failed to load payment settings', false);
            
            // Show error message
            const container = document.getElementById('paymentSettingsContainer');
            container.innerHTML = '<div class="p-3 text-center text-red-500 dark:text-red-400 col-span-2">Failed to load payment options. Please try again.</div>';
        }
    }

    // Function to create a payment option element
    function createPaymentOptionElement(period, amount, label, color) {
        const div = document.createElement('div');
        div.className = `p-3 bg-white dark:bg-gray-700 rounded-lg shadow-sm hover:shadow-md transition-all duration-200`;
        
        const titleDiv = document.createElement('div');
        titleDiv.className = 'flex items-center justify-between mb-2';
        
        const nameSpan = document.createElement('span');
        nameSpan.className = 'text-sm font-medium text-gray-700 dark:text-gray-300';
        nameSpan.textContent = period.charAt(0).toUpperCase() + period.slice(1);
        
        const labelSpan = document.createElement('span');
        labelSpan.className = `px-2 py-0.5 bg-${color}-100 text-${color}-800 dark:bg-${color}-900 dark:text-${color}-200 rounded text-xs`;
        labelSpan.textContent = label;
        
        titleDiv.appendChild(nameSpan);
        titleDiv.appendChild(labelSpan);
        
        const inputDiv = document.createElement('div');
        inputDiv.className = 'flex items-center';
        
        const currencySpan = document.createElement('span');
        currencySpan.className = 'text-lg text-gray-500 dark:text-gray-400';
        currencySpan.textContent = '₹';
        
        const input = document.createElement('input');
        input.type = 'number';
        input.id = `${period}Amount`;
        input.className = 'text-xl font-bold text-gray-800 dark:text-white bg-transparent border-b border-gray-300 dark:border-gray-600 focus:border-indigo-500 dark:focus:border-indigo-400 focus:outline-none px-1 py-0.5 w-24';
        input.value = amount || 0;
        input.min = 0;
        
        inputDiv.appendChild(currencySpan);
        inputDiv.appendChild(input);
        
        div.appendChild(titleDiv);
        div.appendChild(inputDiv);
        
        return div;
    }

    // Function to render custom payment settings
    function renderPaymentSettings() {
        // Get the container for custom payment options
        const container = document.getElementById('currentPaymentOptionsContainer');
        if (!container) return;
        
        // Clear the container
        container.innerHTML = '';
        
        // Check if we have any payment settings
        if (!window.currentPaymentSettings || window.currentPaymentSettings.length === 0) {
            container.innerHTML = '<div class="p-3 text-center text-gray-500 dark:text-gray-400">No custom payment options added yet</div>';
            return;
        }
        
        // Create a table element
        const table = document.createElement('table');
        table.className = 'min-w-full border-collapse text-sm';
        
        // Add table header
        const thead = document.createElement('thead');
        thead.innerHTML = `
            <tr class="bg-gray-100 dark:bg-gray-700">
                <th class="px-3 py-2 text-left text-gray-700 dark:text-gray-300">Option Name</th>
                <th class="px-3 py-2 text-left text-gray-700 dark:text-gray-300">Days</th>
                <th class="px-3 py-2 text-left text-gray-700 dark:text-gray-300">Amount</th>
                <th class="px-3 py-2 text-left text-gray-700 dark:text-gray-300">Actions</th>
            </tr>
        `;
        table.appendChild(thead);
        
        // Add table body
        const tbody = document.createElement('tbody');
        
        // Add each payment setting as a row
        window.currentPaymentSettings.forEach((setting, index) => {
            const row = document.createElement('tr');
            row.className = index % 2 === 0 ? 'bg-white dark:bg-gray-800' : 'bg-gray-50 dark:bg-gray-800/70';
            
            // Name cell
            const nameCell = document.createElement('td');
            nameCell.className = 'px-3 py-2 font-medium text-gray-800 dark:text-gray-200';
            nameCell.textContent = setting.name;
            
            // Days cell
            const daysCell = document.createElement('td');
            daysCell.className = 'px-3 py-2 text-gray-600 dark:text-gray-400';
            daysCell.textContent = setting.days || 'N/A';
            
            // Amount cell
            const amountCell = document.createElement('td');
            amountCell.className = 'px-3 py-2 text-gray-600 dark:text-gray-400';
            amountCell.textContent = `₹${setting.amount}`;
            
            // Actions cell
            const actionsCell = document.createElement('td');
            actionsCell.className = 'px-3 py-2';
            
            const removeButton = document.createElement('button');
            removeButton.className = 'text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300';
            removeButton.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>';
            removeButton.title = 'Remove';
            removeButton.onclick = () => {
                window.currentPaymentSettings.splice(index, 1);
                renderPaymentSettings();
                showToast(`Removed payment option: ${setting.name}`);
            };
            
            actionsCell.appendChild(removeButton);
            
            // Add cells to row
            row.appendChild(nameCell);
            row.appendChild(daysCell);
            row.appendChild(amountCell);
            row.appendChild(actionsCell);
            
            // Add row to table body
            tbody.appendChild(row);
        });
        
        table.appendChild(tbody);
        container.appendChild(table);
    }

    // Function to calculate and display yearly revenue
    async function calculateYearlyRevenue() {
        try {
            const token = localStorage.getItem('ownerToken');
            if (!token) {
                console.error('No authentication token found');
                return;
            }

            const response = await fetch('http://localhost:3000/api/owner/requests', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (!response.ok) {
                throw new Error('Failed to fetch requests');
            }

            const data = await response.json();
            if (!data.success || !data.requests) {
                throw new Error('Invalid response format');
            }

            // Get current year
            const currentYear = new Date().getFullYear();
            
            // Calculate total revenue for this year
            const yearlyRevenue = data.requests.reduce((total, request) => {
                // Check if request is approved and paid
                if (request.status === 'approved' && request.paymentStatus === 'paid') {
                    // Check if the request was approved this year
                    const approvedDate = new Date(request.approvedDate);
                    if (approvedDate.getFullYear() === currentYear) {
                        return total + (request.planAmount || 0);
                    }
                }
                return total;
            }, 0);

            // Update the UI with the calculated revenue
            const revenueElement = document.getElementById('yearly-revenue');
            if (revenueElement) {
                revenueElement.textContent = `₹${yearlyRevenue.toLocaleString()}`;
            }

            // Calculate percentage change from last year (placeholder for now)
            const percentageElement = document.getElementById('revenue-percentage');
            if (percentageElement) {
                percentageElement.textContent = 'vs Last Year: +0%';
            }

        } catch (error) {
            console.error('Error calculating yearly revenue:', error);
            const revenueElement = document.getElementById('yearly-revenue');
            if (revenueElement) {
                revenueElement.textContent = '₹0';
            }
        }
    }
}); 
