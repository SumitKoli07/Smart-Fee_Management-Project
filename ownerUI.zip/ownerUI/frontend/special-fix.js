// Special fix for serviceFee update issue
document.addEventListener('DOMContentLoaded', function() {
    // Make sure this runs after the page is fully loaded
    setTimeout(function() {
        console.log('Running special fix for service fee update...');
        
        // Get the form and button elements
        const paymentSettingsForm = document.getElementById('paymentSettingsForm');
        const savePaymentSettingsBtn = document.getElementById('savePaymentSettingsBtn');
        const serviceFeeInput = document.getElementById('serviceFee');
        
        if (!paymentSettingsForm || !savePaymentSettingsBtn || !serviceFeeInput) {
            console.error('Could not find one or more required elements:');
            console.error('Form:', paymentSettingsForm);
            console.error('Button:', savePaymentSettingsBtn);
            console.error('Input:', serviceFeeInput);
            return;
        }
        
        console.log('Required elements found, attaching handlers...');
        
        // Replace the save button with a new one
        const newSaveButton = document.createElement('button');
        newSaveButton.id = 'savePaymentSettingsBtn';
        newSaveButton.type = 'button'; // Explicitly set as button
        newSaveButton.className = savePaymentSettingsBtn.className;
        newSaveButton.textContent = 'Save Settings';
        
        // Replace the old button with the new one
        savePaymentSettingsBtn.parentNode.replaceChild(newSaveButton, savePaymentSettingsBtn);
        
        // Add a stronger click handler to the new button
        newSaveButton.addEventListener('click', function(e) {
            console.log('SPECIAL FIX: Save button clicked!');
            e.preventDefault();
            
            // Get and validate the service fee
            const feeValue = serviceFeeInput.value.trim();
            const fee = Number(feeValue);
            
            console.log('Service fee value:', feeValue);
            console.log('Parsed service fee:', fee);
            
            if (!feeValue || isNaN(fee) || fee <= 0) {
                alert('Please enter a valid service fee amount!');
                return;
            }
            
            // Get the authorization token
            const token = localStorage.getItem('ownerToken');
            if (!token) {
                alert('Authentication error - please log in again!');
                return;
            }
            
            // Disable the button and show loading state
            newSaveButton.disabled = true;
            newSaveButton.textContent = 'Saving...';
            
            // Get the current payment settings from the window object if available
            const rawPaymentSettings = window.currentPaymentSettings || [];
            
            // Create a direct key-value object for payment settings
            const paymentOptions = {};
            
            // Create a formatted array for backward compatibility
            const formattedPaymentSettings = rawPaymentSettings.map(setting => {
                if (typeof setting === 'object' && setting.name) {
                    // Make sure amount is a valid number
                    const amount = Number(setting.amount) || 0;
                    
                    // Add to direct key-value object
                    const normalizedName = setting.name.toLowerCase().replace(/[-\s]/g, ''); // "Half-Yearly" -> "halfyearly"
                    paymentOptions[normalizedName] = amount;
                    
                    return {
                        name: setting.name,
                        amount: amount
                    };
                } else if (typeof setting === 'string') {
                    // Convert string format to object format with default amount
                    const normalizedName = setting.toLowerCase().replace(/[-\s]/g, '');
                    paymentOptions[normalizedName] = 0;
                    
                    return {
                        name: setting,
                        amount: 0
                    };
                }
                return null;
            }).filter(setting => setting !== null);
            
            console.log('SPECIAL FIX: Formatted payment settings:', JSON.stringify(formattedPaymentSettings));
            console.log('SPECIAL FIX: Payment options as key-value pairs:', JSON.stringify(paymentOptions));
            
            // Extract all payment setting names for the legacy paymentSetting field
            const allPaymentSettingNames = formattedPaymentSettings.map(setting => setting.name);
            const legacyPaymentSetting = allPaymentSettingNames.join(',');
            
            // Extract specific payment period amounts as direct properties
            const monthlyAmount = paymentOptions.monthly || 0;
            const quarterlyAmount = paymentOptions.quarterly || 0;
            const halfYearlyAmount = paymentOptions.halfyearly || 0;
            const yearlyAmount = paymentOptions.yearly || 0;
            
            // Prepare the data to send
            const formData = {
                serviceFee: fee,
                paymentSettings: formattedPaymentSettings,
                paymentSetting: legacyPaymentSetting, // Include all payment setting names as comma-separated
                monthlyAmount,
                quarterlyAmount,
                halfYearlyAmount,
                yearlyAmount,
                paymentOptions: paymentOptions  // Send the direct key-value pairs
            };
            
            console.log('SPECIAL FIX: Sending data directly to API:', JSON.stringify(formData));
            
            // Send the data directly to the API
            fetch('http://localhost:3000/api/owner/payment-settings', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(formData)
            })
            .then(response => {
                console.log('SPECIAL FIX: Response status:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('SPECIAL FIX: Response data:', data);
                
                if (data.success) {
                    alert('Payment settings updated successfully!');
                    
                    // Close the modal
                    const paymentSettingsModal = document.getElementById('paymentSettingsModal');
                    if (paymentSettingsModal) {
                        paymentSettingsModal.classList.add('hidden');
                    }
                    
                    console.log('SPECIAL FIX: Payment settings updated successfully!');
                    
                    // Reload settings to see changes
                    if (typeof loadPaymentSettings === 'function') {
                        setTimeout(loadPaymentSettings, 500);
                    }
                } else {
                    alert('Failed to update payment settings: ' + (data.message || 'Unknown error'));
                    console.error('SPECIAL FIX: Failed to update payment settings:', data.message);
                }
            })
            .catch(error => {
                console.error('SPECIAL FIX: Error saving payment settings:', error);
                alert('Error saving payment settings. Please try again.');
            })
            .finally(() => {
                // Re-enable the button
                newSaveButton.disabled = false;
                newSaveButton.textContent = 'Save Settings';
            });
        });
        
        console.log('SPECIAL FIX: Payment settings update fix applied!');
    }, 1000); // Wait 1 second to ensure the page is fully loaded
}); 