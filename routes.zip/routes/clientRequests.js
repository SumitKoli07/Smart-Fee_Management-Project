const express = require('express');
const router = express.Router();
const Request = require('../models/Request');
const Client = require('../models/clientRegister');
const Owner = require('../models/ownerRegister');
const auth = require('../middleware/auth');

// Create a new service enrollment request
router.post('/enroll-service', auth, async (req, res) => {
    try {
        const { serviceId, ownerId, planType, planAmount, clientInfo } = req.body;
        
        if (!serviceId || !ownerId || !planType) {
            return res.status(400).json({ 
                success: false, 
                message: 'Missing required fields' 
            });
        }
        
        // Parse planAmount as a number if it's a string
        const parsedAmount = typeof planAmount === 'string' ? 
            parseInt(planAmount.replace(/[^0-9]/g, '')) : 
            planAmount;
        
        // Get client information from database to ensure we have the latest data
        const clientId = req.user.id;
        const client = await Client.findById(clientId);
        
        if (!client) {
            return res.status(404).json({
                success: false,
                message: 'Client not found'
            });
        }
        
        // Get service information
        const owner = await Owner.findById(ownerId);
        if (!owner) {
            return res.status(404).json({
                success: false,
                message: 'Service provider not found'
            });
        }
        
        // Check for existing pending requests to prevent duplicates
        const existingRequest = await Request.findOne({
            clientId,
            serviceId,
            status: 'pending'
        });
        
        if (existingRequest) {
            return res.status(400).json({
                success: false,
                message: 'You already have a pending request for this service'
            });
        }
        
        // Create new request with client details
        const request = new Request({
            clientId,
            serviceId,
            ownerId,
            planType,
            planAmount: parsedAmount,
            status: 'pending',
            // Store client details for quick access
            clientDetails: {
                fullname: client.fullname,
                email: client.email,
                mobile: client.mobile,
                address: client.address,
                city: client.city,
                state: client.state
            },
            // Store service details for quick access
            serviceDetails: {
                businessName: owner.businessName,
                serviceName: owner.serviceName,
                ownerName: owner.ownerName
            }
        });

        await request.save();
        
        res.status(201).json({ 
            success: true,
            message: 'Enrollment request created successfully', 
            request 
        });
    } catch (error) {
        console.error('Error creating enrollment request:', error);
        res.status(500).json({ 
            success: false,
            message: 'Error creating enrollment request',
            error: error.message
        });
    }
});

// Get all pending requests for a service owner
router.get('/pending-requests', auth, async (req, res) => {
    try {
        const requests = await Request.find({ 
            ownerId: req.user.id,
            status: 'pending'
        }).populate('clientId', 'fullname email mobile')
          .populate('serviceId', 'serviceName businessName');
        
        res.json({
            success: true,
            requests
        });
    } catch (error) {
        console.error('Error fetching pending requests:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error fetching pending requests' 
        });
    }
});

// Update request status (approve/reject)
router.put('/update-request/:id', auth, async (req, res) => {
    try {
        const { status, notes } = req.body;
        
        const request = await Request.findById(req.params.id);
        
        if (!request) {
            return res.status(404).json({ 
                success: false,
                message: 'Request not found' 
            });
        }
        
        if (request.ownerId.toString() !== req.user.id) {
            return res.status(403).json({ 
                success: false,
                message: 'Not authorized to update this request' 
            });
        }
        
        request.status = status;
        request.notes = notes;
        
        if (status === 'approved') {
            request.approvedDate = new Date();
        }
        
        await request.save();
        
        res.json({ 
            success: true,
            message: 'Request updated successfully', 
            request 
        });
    } catch (error) {
        console.error('Error updating request:', error);
        res.status(500).json({ 
            success: false,
            message: 'Error updating request',
            error: error.message
        });
    }
});

// Get client's enrollment requests
router.get('/my-requests', auth, async (req, res) => {
    try {
        const requests = await Request.find({ 
            clientId: req.user.id
        }).sort({ requestDate: -1 }); // Most recent first
        
        res.json({ 
            success: true,
            requests 
        });
    } catch (error) {
        console.error('Error fetching client requests:', error);
        res.status(500).json({ 
            success: false,
            message: 'Error fetching your enrollment requests' 
        });
    }
});

module.exports = router; 