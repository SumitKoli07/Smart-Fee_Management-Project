const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Request = require('../models/Request');
const Owner = require('../models/ownerRegister');
const auth = require('../middleware/auth');

// Debug helper - log all requests to this router
router.use((req, res, next) => {
    console.log(`Request to /requests${req.path} endpoint at ${new Date().toISOString()}`);
    next();
});

// Enroll a client in a service with pending status
router.post('/enroll', auth, async (req, res) => {
    try {
        const { serviceId, planType, planAmount } = req.body;
        
        if (!serviceId || !planType) {
            return res.status(400).json({ 
                success: false, 
                message: 'Missing required fields' 
            });
        }
        
        // Find the owner of the service
        const service = await Owner.findById(serviceId);
        
        if (!service) {
            return res.status(404).json({ 
                success: false, 
                message: 'Service not found' 
            });
        }
        
        // Create new request with owner ID from the service
        const request = new Request({
            clientId: req.user.id,
            serviceId,
            ownerId: service._id, // The service owner's ID
            planType,
            planAmount,
            status: 'pending'
        });

        await request.save();
        
        res.status(201).json({ 
            success: true, 
            message: 'Enrollment request created successfully',
            request 
        });
    } catch (error) {
        console.error('Error creating enrollment request:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error processing your request'
        });
    }
});

// Get all pending requests for a service owner
router.get('/pending', auth, async (req, res) => {
    try {
        const requests = await Request.find({ 
            ownerId: req.user.id,
            status: 'pending'
        }).populate('clientId', 'fullname email mobile')
          .populate('serviceId', 'serviceName businessName');
        
        res.json({
            success: true,
            requests
        });
    } catch (error) {
        console.error('Error fetching pending requests:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error fetching pending requests' 
        });
    }
});

// Get all approved requests for a service owner
router.get('/approved', auth, async (req, res) => {
    try {
        console.log('Approved requests endpoint hit');
        console.log('Auth user object:', req.user);
        
        if (!req.user || !req.user.id) {
            console.log('No valid user ID found in the token');
            return res.status(401).json({
                success: false,
                message: 'User ID not found in token'
            });
        }
        
        console.log('Fetching approved requests for owner:', req.user.id);
        
        // Find all approved requests for this owner
        const requests = await Request.find({ 
            ownerId: req.user.id,
            status: 'approved'
        }).populate('clientId', 'fullname email mobile')
          .populate('serviceId', 'serviceName businessName');
        
        console.log(`Found ${requests.length} approved requests`);
        console.log('MongoDB Query:', { ownerId: req.user.id, status: 'approved' });
        
        // Add some debug info about the found requests
        if (requests.length > 0) {
            console.log('Sample request data:', {
                id: requests[0]._id,
                clientId: requests[0].clientId,
                ownerId: requests[0].ownerId,
                status: requests[0].status
            });
            
            // Process each request to ensure it has the required fields
            const processedRequests = requests.map(request => {
                // Create a new object with the request data
                const processedRequest = request.toObject();
                
                // Ensure clientId is populated, or use clientDetails as fallback
                if (!processedRequest.clientId || typeof processedRequest.clientId !== 'object') {
                    processedRequest.clientId = {
                        fullname: processedRequest.clientDetails?.fullname || 'Unknown',
                        email: processedRequest.clientDetails?.email || '',
                        mobile: processedRequest.clientDetails?.mobile || 'N/A'
                    };
                }
                
                return processedRequest;
            });
            
            res.json({
                success: true,
                requests: processedRequests
            });
        } else {
            res.json({
                success: true,
                requests: []
            });
        }
    } catch (error) {
        console.error('Error fetching approved requests:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error fetching approved requests' 
        });
    }
});

// Update request status (approve/reject)
router.put('/update/:id', auth, async (req, res) => {
    try {
        const { status, notes } = req.body;
        
        if (!['approved', 'rejected'].includes(status)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid status value'
            });
        }
        
        const request = await Request.findById(req.params.id);
        
        if (!request) {
            return res.status(404).json({ 
                success: false, 
                message: 'Request not found' 
            });
        }
        
        if (request.ownerId.toString() !== req.user.id) {
            return res.status(403).json({ 
                success: false, 
                message: 'Not authorized to update this request' 
            });
        }
        
        request.status = status;
        request.notes = notes;
        
        if (status === 'approved') {
            const approvalDate = new Date();
            request.approvedDate = approvalDate;
            request.nextDueDate = approvalDate; // Set nextDueDate to same as approvedDate
            console.log(`Request ${request._id} approved with approvedDate and nextDueDate set to:`, approvalDate);
        }
        
        await request.save();
        
        res.json({ 
            success: true, 
            message: `Request ${status} successfully`, 
            request 
        });
    } catch (error) {
        console.error('Error updating request:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error updating request' 
        });
    }
});

module.exports = router; 