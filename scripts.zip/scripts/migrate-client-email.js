const mongoose = require('mongoose');
const Request = require('../models/Request');
const Client = require('../models/clientRegister');

// MongoDB connection string
const MONGO_URI = 'mongodb://127.0.0.1:27017/mp';

// Connect to MongoDB
mongoose.connect(MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => {
    console.log('Connected to MongoDB');
    migrateClientEmails();
})
.catch(err => {
    console.error('Error connecting to MongoDB:', err);
    process.exit(1);
});

async function migrateClientEmails() {
    try {
        console.log('Starting migration of client emails to requests...');
        
        // Get all requests that don't have clientEmail field
        const requests = await Request.find({ 
            $or: [
                { clientEmail: { $exists: false } },
                { clientEmail: null },
                { clientEmail: '' }
            ]
        });
        
        console.log(`Found ${requests.length} requests without clientEmail field`);
        
        let updatedCount = 0;
        let errorCount = 0;
        
        // Process each request
        for (const request of requests) {
            try {
                // Check if email exists in clientDetails
                if (request.clientDetails && request.clientDetails.email) {
                    request.clientEmail = request.clientDetails.email;
                    await request.save();
                    updatedCount++;
                    console.log(`Updated request ${request._id} with email from clientDetails: ${request.clientEmail}`);
                    continue;
                }
                
                // If not in clientDetails, try to get from Client collection
                if (request.clientId) {
                    const client = await Client.findById(request.clientId);
                    if (client && client.email) {
                        request.clientEmail = client.email;
                        
                        // Also update clientDetails if it exists
                        if (request.clientDetails) {
                            request.clientDetails.email = client.email;
                        }
                        
                        await request.save();
                        updatedCount++;
                        console.log(`Updated request ${request._id} with email from Client: ${request.clientEmail}`);
                        continue;
                    }
                }
                
                console.log(`Could not find email for request ${request._id}`);
                errorCount++;
            } catch (err) {
                console.error(`Error updating request ${request._id}:`, err);
                errorCount++;
            }
        }
        
        console.log('Migration completed!');
        console.log(`Successfully updated: ${updatedCount} requests`);
        console.log(`Failed to update: ${errorCount} requests`);
        
        mongoose.disconnect();
        console.log('Disconnected from MongoDB');
    } catch (error) {
        console.error('Migration error:', error);
        mongoose.disconnect();
        process.exit(1);
    }
} 