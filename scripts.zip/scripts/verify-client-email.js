const mongoose = require('mongoose');
const Request = require('../models/Request');

// MongoDB connection string
const MONGO_URI = 'mongodb://127.0.0.1:27017/mp';

// Connect to MongoDB
mongoose.connect(MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => {
    console.log('Connected to MongoDB');
    verifyClientEmails();
})
.catch(err => {
    console.error('Error connecting to MongoDB:', err);
    process.exit(1);
});

async function verifyClientEmails() {
    try {
        console.log('Starting verification of client emails in requests...');
        
        // Get all requests
        const allRequests = await Request.find({});
        console.log(`Found ${allRequests.length} total requests`);
        
        // Get requests with clientEmail
        const requestsWithEmail = await Request.find({
            clientEmail: { $exists: true, $ne: null, $ne: '' }
        });
        console.log(`Found ${requestsWithEmail.length} requests with clientEmail field`);
        
        // Get requests without clientEmail
        const requestsWithoutEmail = await Request.find({
            $or: [
                { clientEmail: { $exists: false } },
                { clientEmail: null },
                { clientEmail: '' }
            ]
        });
        console.log(`Found ${requestsWithoutEmail.length} requests without clientEmail field`);
        
        // Show a sample of requests with email
        if (requestsWithEmail.length > 0) {
            console.log('\nSample requests with clientEmail:');
            for (let i = 0; i < Math.min(3, requestsWithEmail.length); i++) {
                const request = requestsWithEmail[i];
                console.log(`Request ID: ${request._id}`);
                console.log(`  clientEmail: ${request.clientEmail}`);
                console.log(`  clientDetails.email: ${request.clientDetails?.email || 'N/A'}`);
                console.log('--------------');
            }
        }
        
        // Show all requests without email
        if (requestsWithoutEmail.length > 0) {
            console.log('\nAll requests without clientEmail:');
            for (const request of requestsWithoutEmail) {
                console.log(`Request ID: ${request._id}`);
                console.log(`  status: ${request.status}`);
                console.log(`  clientDetails.email: ${request.clientDetails?.email || 'N/A'}`);
                console.log('--------------');
            }
        }
        
        console.log('\nVerification completed!');
        mongoose.disconnect();
        console.log('Disconnected from MongoDB');
    } catch (error) {
        console.error('Verification error:', error);
        mongoose.disconnect();
        process.exit(1);
    }
} 