const fetch = require('node-fetch');

// Replace this with a valid owner token from your localStorage
const OWNER_TOKEN = process.argv[2]; // Pass token as command line argument

if (!OWNER_TOKEN) {
    console.error('Please provide an owner token as a command line argument');
    console.error('Example: node scripts/test-api-response.js YOUR_TOKEN_HERE');
    process.exit(1);
}

async function testClientApiResponse() {
    try {
        console.log('Testing /api/clients API response...');
        
        const response = await fetch('http://localhost:3000/api/clients', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${OWNER_TOKEN}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        
        const clients = await response.json();
        console.log(`Received ${clients.length} clients from API`);
        
        if (clients.length > 0) {
            console.log('\nChecking first client for email field:');
            const firstClient = clients[0];
            console.log(JSON.stringify(firstClient, null, 2));
            
            if (firstClient.email) {
                console.log('\n✅ clientEmail field is present in API response');
            } else {
                console.log('\n❌ clientEmail field is MISSING in API response');
            }
        } else {
            console.log('No clients returned from API');
        }
    } catch (error) {
        console.error('Error testing API:', error);
    }
}

testClientApiResponse(); 